#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void cargarMatriz (int filas, int columnas, int A[filas][columnas]);
void mostrarMatriz(int filas, int columnas, int A[filas][columnas]);
void cargarMatrizRandom(int filas, int columnas, int A[filas][columnas]);
int sumaElementosMatriz(int filas, int columnas, int A[filas][columnas]);
float promedioMatriz(int filas, int columnas, int A[filas][columnas]);
int buscarElemento(int filas, int columnas, int A[filas][columnas], int numero);



int main()
{
    srand(time(NULL));

    int controlSwitch;
    char salirSwitch;
    int unaMatriz [20][20];
    int fil=0, col=0,resultado=0, unNumero=0, estaElemento=0;
    float promedio=0;



    do
    {
        printf("que ejercicio quiere correr?\n");
        printf("1 y 2.	Hacer una funci�n que reciba como par�metro una matriz de n�meros enteros y permita que el usuario ingrese valores al mismo por teclado. La funci�n debe cargar la matriz por completo.\n");
        printf("3.	Hacer una funci�n que reciba como par�metro una matriz de n�meros enteros y que cargue la misma con n�meros aleatorios (sin intervenci�n del usuario).\n");
        printf("4.	Hacer una funci�n tipo int que sume el contenido total de una matriz de n�meros enteros.\n");
        printf("5.	Hacer una funci�n tipo float que calcule el promedio de una matriz de n�meros enteros.\n");
        printf("6.	Hacer una funci�n que determine si un elemento se encuentra dentro de una matriz de n�meros enteros. La funci�n recibe la matriz y el dato a buscar.\n");



        fflush(stdin);
        scanf("%d", &controlSwitch);

        switch(controlSwitch)
        {



        case 1:
            puts("cuantas filas tiene la matriz?\n");
            scanf("%d",&fil);

            puts("cuantas columnas tiene la matriz?\n");
            scanf("%d",&col);


            cargarMatriz(fil, col, unaMatriz);
            mostrarMatriz(fil, col, unaMatriz);


            break;
        case 3:
            puts("cuantas filas tiene la matriz?\n");
            scanf("%d",&fil);

            puts("cuantas columnas tiene la matriz?\n");
            scanf("%d",&col);


            cargarMatrizRandom(fil, col, unaMatriz);
            mostrarMatriz(fil, col, unaMatriz);


            break;


        case 4:
            puts("cuantas filas tiene la matriz?\n");
            scanf("%d",&fil);

            puts("cuantas columnas tiene la matriz?\n");
            scanf("%d",&col);


            cargarMatrizRandom(fil, col, unaMatriz);
            mostrarMatriz(fil, col, unaMatriz);
            resultado = sumaElementosMatriz(fil, col,unaMatriz);
            printf("la suma de los elementos de la matriz es: %d", resultado);

            break;

        case 5:
            puts("cuantas filas tiene la matriz?\n");
            scanf("%d",&fil);

            puts("cuantas columnas tiene la matriz?\n");
            scanf("%d",&col);


            cargarMatrizRandom(fil, col, unaMatriz);
            mostrarMatriz(fil, col, unaMatriz);
            promedio = promedioMatriz(fil, col,unaMatriz);
            printf("el promedio de los elementos de la matriz es: %f", promedio);

            break;
        case 6:
            puts("cuantas filas tiene la matriz?\n");
            scanf("%d",&fil);

            puts("cuantas columnas tiene la matriz?\n");
            scanf("%d",&col);
            puts("ingrese el numero a buscar\n");
            scanf("%d",&unNumero);


            cargarMatrizRandom(fil, col, unaMatriz);
            mostrarMatriz(fil, col, unaMatriz);

            estaElemento = buscarElemento(fil, col, unaMatriz, unNumero);
            printf("esta elemento = %d \n", estaElemento);

            if(estaElemento != 1)
            {
                puts("el elemento no esta en la matriz\n");
            }
            if(estaElemento == 1 )
            {
                puts("el numero esta dentro de la matriz\n");
            }



            break;

        case 7:





            break;

        case 8:


            break;

        case 9:

            break;

        case 10:

            break;

        case 11:

            break;

        }
        puts("\nDesea continuar con otro ejercicio? s/n\n");
        fflush(stdin);
        scanf("%c", &salirSwitch);

    }
    while(salirSwitch != 'n');

    return 0;
}

void cargarMatriz (int filas, int columnas, int A[filas][columnas])
{
///cargar matriz
    int f=0, c=0;
    for(f=0; f<filas; f++)
    {
        for(c=0; c<columnas; c++)
        {
            printf("ingrese el valor para la posicion %d%d \n",f, c );
            scanf("%d", &A[f][c]);

        }

    }
}
///mostrarMatriz
void mostrarMatriz(int filas, int columnas, int A[filas][columnas])
{
    int f=0, c=0;
    for(f=0; f<filas; f++)
    {
        for(c=0; c<columnas; c++)
        {
            printf(" -%d- ",A[f][c]);

        }
        printf("\n");

    }

}
void cargarMatrizRandom(int filas, int columnas, int A[filas][columnas])
{
    int f=0, c=0;
    for(f=0; f<filas; f++)
    {
        for(c=0; c<columnas; c++)
        {
            A[f][c]= rand()%50;
        }

    }
}
int sumaElementosMatriz(int filas, int columnas, int A[filas][columnas])
{
    int f=0, c=0, suma=0;
    for(f=0; f<filas; f++)
    {
        for(c=0; c<columnas; c++)
        {
            suma += A[f][c];

        }

    }

    return suma;
}

float promedioMatriz(int filas, int columnas, int A[filas][columnas])
{
    int f=0, c=0, suma=0,cont=0;
    for(f=0; f<filas; f++)
    {
        for(c=0; c<columnas; c++)
        {
            suma += A[f][c];
            cont++;

        }
    }
    return (float)suma/cont;


}

int buscarElemento(int filas, int columnas, int A[filas][columnas], int numero)
{

    int f=0, c=0, flag=0;
    for(f=0; f<filas && flag==0; f++)
    {
        for(c=0; c<columnas && flag==0; c++)
        {
            if(A[f][c]==numero)
            {
                flag = 1;
            }

        }

    }
    return flag;
}



/*
7.	Hacer una funci�n que cargue un arreglo de palabras (strings). La funci�n debe retornar cuantas palabras se cargaron.  (puede ser a trav�s del par�metro como puntero)
8.	Hacer una funci�n que muestre un arreglo de palabras.
9.	Hacer una funci�n que determine si un string se encuentra dentro de un arreglo de strings. La funci�n recibe el arreglo, la cantidad de palabras que contiene y la palabra a buscar. ///devuelve el �ndice de la fila en que se encuentra, de lo contrario -1
10.	Hacer una funci�n que determine si un string se encuentra dentro de un arreglo de strings ordenado alfab�ticamente. La funci�n recibe el arreglo, la cantidad de palabras que contiene y el string a buscar.  ///devuelve el �ndice de la fila en que se encuentra, de lo contrario -1
11.	Hacer una funci�n (o varias) que ordene un arreglo de palabras por orden alfab�tico. (Por selecci�n o inserci�n, el que m�s te guste).
12.	Hacer una funci�n que retorne el determinante de una matriz de 2x2.
13.	Funci�n que verifique si una matriz de 2x2 tiene inversa.
14.	Hacer una funci�n que multiplique una matriz de 2x2 por una matriz de 2x5.
15.	Hacer una funci�n que calcule la matriz inversa de una matriz de 2x2.
*/
